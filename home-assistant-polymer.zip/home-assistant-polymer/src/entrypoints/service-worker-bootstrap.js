/* global importScripts */
importScripts("/static/service-worker-hass.js");
