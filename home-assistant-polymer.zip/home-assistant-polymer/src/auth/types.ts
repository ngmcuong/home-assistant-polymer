export interface SignedPath {
  path: string;
}
